const contractABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			}
		],
		"name": "CopyrightCreated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightDeleted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightEdited",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "purchaser",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightPurchased",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "verifier",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightVerified",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_price",
				"type": "uint256"
			}
		],
		"name": "createCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "deleteCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_price",
				"type": "uint256"
			}
		],
		"name": "editCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "purchaseCopyright",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "recipient",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "RefundIssued",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "requestRefund",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"stateMutability": "payable",
		"type": "receive"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "copyrightOwners",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "copyrights",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isAdopted",
				"type": "bool"
			},
			{
				"internalType": "uint256",
				"name": "purchaseTimestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getAllCopyrights",
		"outputs": [
			{
				"components": [
					{
						"internalType": "uint256",
						"name": "id",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "name",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "imageURL",
						"type": "string"
					},
					{
						"internalType": "uint256",
						"name": "price",
						"type": "uint256"
					},
					{
						"internalType": "bool",
						"name": "isAdopted",
						"type": "bool"
					},
					{
						"internalType": "uint256",
						"name": "purchaseTimestamp",
						"type": "uint256"
					}
				],
				"internalType": "struct CopyrightManagement.Copyright[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "getCopyright",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isAdopted",
				"type": "bool"
			},
			{
				"internalType": "uint256",
				"name": "purchaseTimestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "verifyCopyright",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];
const contractAddress = "0x1471b97f58C286bB7C583a8A66F08d5846308Ff6";

let allEvents = []; // Store all events

window.addEventListener('load', async () => {
    if (window.ethereum) {
        const web3 = new Web3(window.ethereum);
        const contract = new web3.eth.Contract(contractABI, contractAddress);

        console.log("Web3 and contract initialized");

        // Fetch past events from the blockchain
        async function fetchPastEvents() {
            try {
                const pastEvents = await Promise.all([
                    contract.getPastEvents('CopyrightPurchased', {
                        fromBlock: 0,
                        toBlock: 'latest'
                    }),
                    contract.getPastEvents('RefundIssued', {
                        fromBlock: 0,
                        toBlock: 'latest'
                    }),
                    contract.getPastEvents('CopyrightCreated', {
                        fromBlock: 0,
                        toBlock: 'latest'
                    }),
                    contract.getPastEvents('CopyrightEdited', {
                        fromBlock: 0,
                        toBlock: 'latest'
                    }),
                    contract.getPastEvents('CopyrightDeleted', {
                        fromBlock: 0,
                        toBlock: 'latest'
                    })
                ]);
        
                console.log("Past events:", pastEvents);
        
                // Flatten the array of events
                allEvents = [...pastEvents[0], ...pastEvents[1], ...pastEvents[2], ...pastEvents[3], ...pastEvents[4]];
        
                // Sort and update the table
                await sortAndUpdateTable();
            } catch (error) {
                console.error("Error fetching past events:", error);
            }
        }

        // Call the function to load past events
        fetchPastEvents();

        // Subscribe to live events
        contract.events.CopyrightPurchased()
    .on('data', async (event) => {
        console.log("New CopyrightPurchased event detected:", event);
        await addEventAndUpdate(event);
    })
    .on('error', (error) => {
        console.error("Error in live event subscription:", error);
    });

contract.events.RefundIssued()
    .on('data', async (event) => {
        console.log("New RefundIssued event detected:", event);
        await addEventAndUpdate(event);
    })
    .on('error', (error) => {
        console.error("Error in live event subscription:", error);
    });

contract.events.CopyrightCreated()
    .on('data', async (event) => {
        console.log("New CopyrightCreated event detected:", event);
        await addEventAndUpdate(event);
    })
    .on('error', (error) => {
        console.error("Error in live event subscription:", error);
    });

contract.events.CopyrightEdited()
    .on('data', async (event) => {
        console.log("New CopyrightEdited event detected:", event);
        await addEventAndUpdate(event);
    })
    .on('error', (error) => {
        console.error("Error in live event subscription:", error);
    });

contract.events.CopyrightDeleted()
    .on('data', async (event) => {
        console.log("New CopyrightDeleted event detected:", event);
        await addEventAndUpdate(event);
    })
    .on('error', (error) => {
        console.error("Error in live event subscription:", error);
    });

        // Function to sort events and update the table
        async function sortAndUpdateTable() {
            // Sort events by block number (latest first)
            allEvents.sort((a, b) => b.blockNumber - a.blockNumber);

            const logTableBody = document.getElementById('logTableBody');
            if (!logTableBody) {
                console.error("Table body element not found");
                return;
            }

            // Clear existing rows
            logTableBody.innerHTML = '';

            // Append sorted events to the table
            for (const event of allEvents) {
                await appendToTable(event, logTableBody);
            }
        }

        // Function to append events to the table
        async function appendToTable(event, logTableBody) {
            // Fetch the block data to get the timestamp
            const block = await web3.eth.getBlock(event.blockNumber);
            const timestamp = new Date(block.timestamp * 1000); // Convert to readable date

            // Fetch transaction details
            const transaction = await web3.eth.getTransaction(event.transactionHash);
            const fromAddress = transaction.from;
            const toAddress = transaction.to;

            // Create a new row
            const newRow = logTableBody.insertRow(-1); // Insert at the end, we've already sorted

            // Add cells and populate them with event data
            if (event.event === 'CopyrightPurchased') {
                newRow.insertCell(0).innerText = "Copyright Purchased";
                newRow.insertCell(1).innerText = event.returnValues.copyrightId;
                newRow.insertCell(2).innerText = timestamp.toLocaleString();
                newRow.insertCell(3).innerText = event.transactionHash;
                newRow.insertCell(4).innerText = event.returnValues.purchaser;
                newRow.insertCell(5).innerText = toAddress;
            } else if (event.event === 'RefundIssued') {
                newRow.insertCell(0).innerText = "Refund Issued";
                newRow.insertCell(1).innerText = event.returnValues.copyrightId;
                newRow.insertCell(2).innerText = timestamp.toLocaleString();
                newRow.insertCell(3).innerText = event.transactionHash;
                newRow.insertCell(4).innerText = event.returnValues.recipient;
                newRow.insertCell(5).innerText = toAddress;
            } else if (event.event === 'CopyrightCreated') {
                newRow.insertCell(0).innerText = "Copyright Created";
                newRow.insertCell(1).innerText = event.returnValues.copyrightId;
                newRow.insertCell(2).innerText = timestamp.toLocaleString();
                newRow.insertCell(3).innerText = event.transactionHash;
                newRow.insertCell(4).innerText = event.returnValues.owner;
                newRow.insertCell(5).innerText = toAddress;
            } else if (event.event === 'CopyrightEdited') {
                newRow.insertCell(0).innerText = "Copyright Edited";
                newRow.insertCell(1).innerText = event.returnValues.copyrightId;
                newRow.insertCell(2).innerText = timestamp.toLocaleString();
                newRow.insertCell(3).innerText = event.transactionHash;
                newRow.insertCell(4).innerText = fromAddress
                newRow.insertCell(5).innerText = toAddress;
            } else if (event.event === 'CopyrightDeleted') {
                newRow.insertCell(0).innerText = "Copyright Deleted";
                newRow.insertCell(1).innerText = event.returnValues.copyrightId;
                newRow.insertCell(2).innerText = timestamp.toLocaleString();
                newRow.insertCell(3).innerText = event.transactionHash;
                newRow.insertCell(4).innerText = fromAddress
                newRow.insertCell(5).innerText = toAddress;
            }
        }
    }
});