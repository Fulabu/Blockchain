const contractABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			}
		],
		"name": "CopyrightCreated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightDeleted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightEdited",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "purchaser",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightPurchased",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "verifier",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightVerified",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_price",
				"type": "uint256"
			}
		],
		"name": "createCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "deleteCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_price",
				"type": "uint256"
			}
		],
		"name": "editCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "purchaseCopyright",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "recipient",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "RefundIssued",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "requestRefund",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"stateMutability": "payable",
		"type": "receive"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "copyrightOwners",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "copyrights",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isAdopted",
				"type": "bool"
			},
			{
				"internalType": "uint256",
				"name": "purchaseTimestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getAllCopyrights",
		"outputs": [
			{
				"components": [
					{
						"internalType": "uint256",
						"name": "id",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "name",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "imageURL",
						"type": "string"
					},
					{
						"internalType": "uint256",
						"name": "price",
						"type": "uint256"
					},
					{
						"internalType": "bool",
						"name": "isAdopted",
						"type": "bool"
					},
					{
						"internalType": "uint256",
						"name": "purchaseTimestamp",
						"type": "uint256"
					}
				],
				"internalType": "struct CopyrightManagement.Copyright[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "getCopyright",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isAdopted",
				"type": "bool"
			},
			{
				"internalType": "uint256",
				"name": "purchaseTimestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "verifyCopyright",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];
const contractAddress = "0x1471b97f58C286bB7C583a8A66F08d5846308Ff6";

window.addEventListener('load', async () => {
    if (window.ethereum) {
        const web3 = new Web3(window.ethereum);
        await ethereum.request({ method: 'eth_requestAccounts' });
        const contract = new web3.eth.Contract(contractABI, contractAddress);

        // Function to display all copyrights
        async function displayCopyrights() {
            try {
                const copyrights = await contract.methods.getAllCopyrights().call();
                const listDiv = document.getElementById('copyrights-list');
                listDiv.innerHTML = ''; // Clear previous content
                copyrights.forEach(copyright => {
                    const item = document.createElement('div');
                    item.className = 'copyright-item';
                    item.innerHTML = `
                        <h3>ID: ${copyright.id} - ${copyright.name}</h3>
                        <p>${copyright.description}</p>
                        <img src="${copyright.imageURL}" alt="${copyright.name}" style="width: 100px;">
                        <p>Price: ${web3.utils.fromWei(copyright.price, 'ether')} ETH</p>
                        ${copyright.isAdopted ? '<p>Already Purchased</p>' : '<button onclick="purchaseCopyright(' + copyright.id + ')">Purchase</button>'}
                    `;
                    listDiv.appendChild(item);
                });
            } catch (error) {
                console.error('Error fetching copyrights:', error);
            }
        }

        window.purchaseCopyright = async (id) => {
            const accounts = await web3.eth.getAccounts();
            const account = accounts[0];

            try {
                // Fetch the actual price of the selected copyright
                const copyright = await contract.methods.getCopyright(id).call();
                const price = copyright.price; // price in Wei
                
                // Initiate the purchase transaction with the actual price
                await contract.methods.purchaseCopyright(id).send({ from: account, value: price });
                alert('Purchase successful!');
                displayCopyrights();
            } catch (error) {
                console.error('Error purchasing copyright:', error);
            }
        };

        // Display all copyrights when the page loads
        displayCopyrights();
    } else {
        console.warn('Please install MetaMask!');
    }
});
