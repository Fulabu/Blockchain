window.addEventListener('load', async () => {
    const connectButton = document.getElementById('connectButton');
    const logoutButton = document.getElementById('logoutButton');
    const viewProfileButton = document.getElementById('viewProfileButton');
    const viewCopyrightsButton = document.getElementById('viewCopyrightsButton');
    const accountDisplay = document.getElementById('accountDisplay');
    const adminButton = document.getElementById('adminButton');

    let web3;
    let contract;
    let account;
    const contractAddress = "0x1471b97f58C286bB7C583a8A66F08d5846308Ff6"; // Replace with your contract address
    const contractABI = [
        {
            "inputs": [],
            "stateMutability": "nonpayable",
            "type": "constructor"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                },
                {
                    "indexed": false,
                    "internalType": "address",
                    "name": "owner",
                    "type": "address"
                }
            ],
            "name": "CopyrightCreated",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightDeleted",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightEdited",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "purchaser",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightPurchased",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "verifier",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightVerified",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "string",
                    "name": "_name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "_price",
                    "type": "uint256"
                }
            ],
            "name": "createCopyright",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "deleteCopyright",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "_name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "_price",
                    "type": "uint256"
                }
            ],
            "name": "editCopyright",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "purchaseCopyright",
            "outputs": [],
            "stateMutability": "payable",
            "type": "function"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "recipient",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "RefundIssued",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "requestRefund",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "stateMutability": "payable",
            "type": "receive"
        },
        {
            "inputs": [],
            "name": "admin",
            "outputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "copyrightOwners",
            "outputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "copyrights",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "id",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "price",
                    "type": "uint256"
                },
                {
                    "internalType": "bool",
                    "name": "isAdopted",
                    "type": "bool"
                },
                {
                    "internalType": "uint256",
                    "name": "purchaseTimestamp",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "getAllCopyrights",
            "outputs": [
                {
                    "components": [
                        {
                            "internalType": "uint256",
                            "name": "id",
                            "type": "uint256"
                        },
                        {
                            "internalType": "string",
                            "name": "name",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "description",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "imageURL",
                            "type": "string"
                        },
                        {
                            "internalType": "uint256",
                            "name": "price",
                            "type": "uint256"
                        },
                        {
                            "internalType": "bool",
                            "name": "isAdopted",
                            "type": "bool"
                        },
                        {
                            "internalType": "uint256",
                            "name": "purchaseTimestamp",
                            "type": "uint256"
                        }
                    ],
                    "internalType": "struct CopyrightManagement.Copyright[]",
                    "name": "",
                    "type": "tuple[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "getCopyright",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "id",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "price",
                    "type": "uint256"
                },
                {
                    "internalType": "bool",
                    "name": "isAdopted",
                    "type": "bool"
                },
                {
                    "internalType": "uint256",
                    "name": "purchaseTimestamp",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "verifyCopyright",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        }
    ]; // Replace with your contract ABI

    async function initWeb3() {
        if (window.ethereum) {
            web3 = new Web3(window.ethereum);
            contract = new web3.eth.Contract(contractABI, contractAddress);
        } else {
            alert('Please install MetaMask to use this app.');
        }
    }

    async function updateUI() {
        if (web3) {
            const accounts = await web3.eth.getAccounts();
            if (accounts.length > 0) {
                account = accounts[0];
                accountDisplay.innerText = `Currently Logged in as: ${account}`;
                connectButton.style.display = 'none';
                logoutButton.style.display = 'block';
                viewProfileButton.style.display = 'block';
                viewCopyrightsButton.style.display = 'block';

                // Check if the logged-in account is the admin
                checkAdmin();
            } else {
                accountDisplay.innerText = 'Please log in to MetaMask.';
                connectButton.style.display = 'block';
                logoutButton.style.display = 'none';
                viewProfileButton.style.display = 'none';
                viewCopyrightsButton.style.display = 'none';
                adminButton.style.display = 'none'; // Hide admin button if not logged in
            }
        }
    }

    async function checkAdmin() {
        try {
            const adminAddress = await contract.methods.admin().call();
            if (adminAddress.toLowerCase() === account.toLowerCase()) {
                adminButton.style.display = 'block'; // Show the admin button if account is admin
            } else {
                adminButton.style.display = 'none'; // Hide the admin button if not admin
            }
        } catch (error) {
            console.error('Error fetching admin address:', error);
        }
    }

    connectButton.addEventListener('click', async () => {
        if (window.ethereum) {
            try {
                await ethereum.request({ method: 'eth_requestAccounts' });
                updateUI();
                window.location.href = 'copyrights.html'; // Redirect to the copyrights page
            } catch (error) {
                console.error('User denied account access');
            }
        } else {
            alert('Please install MetaMask to use this app.');
        }
    });

    logoutButton.addEventListener('click', () => {
        account = null;
        accountDisplay.innerText = '';
        connectButton.style.display = 'block';
        logoutButton.style.display = 'none';
        viewProfileButton.style.display = 'none';
        viewCopyrightsButton.style.display = 'none';
        adminButton.style.display = 'none'; // Hide admin button on logout
    });

    // Initialize Web3 and update UI on page load
    await initWeb3();
    updateUI();
});
