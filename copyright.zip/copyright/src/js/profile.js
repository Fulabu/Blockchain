// src/js/profile.js

// Define your contract ABI and address here
const CONTRACT_ABI = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			},
			{
				"indexed": false,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			}
		],
		"name": "CopyrightCreated",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightDeleted",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightEdited",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "purchaser",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightPurchased",
		"type": "event"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "verifier",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "CopyrightVerified",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_price",
				"type": "uint256"
			}
		],
		"name": "createCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "deleteCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "_imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "_price",
				"type": "uint256"
			}
		],
		"name": "editCopyright",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "purchaseCopyright",
		"outputs": [],
		"stateMutability": "payable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": true,
				"internalType": "address",
				"name": "recipient",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "copyrightId",
				"type": "uint256"
			}
		],
		"name": "RefundIssued",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "requestRefund",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"stateMutability": "payable",
		"type": "receive"
	},
	{
		"inputs": [],
		"name": "admin",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "copyrightOwners",
		"outputs": [
			{
				"internalType": "address",
				"name": "",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "copyrights",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isAdopted",
				"type": "bool"
			},
			{
				"internalType": "uint256",
				"name": "purchaseTimestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getAllCopyrights",
		"outputs": [
			{
				"components": [
					{
						"internalType": "uint256",
						"name": "id",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "name",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "description",
						"type": "string"
					},
					{
						"internalType": "string",
						"name": "imageURL",
						"type": "string"
					},
					{
						"internalType": "uint256",
						"name": "price",
						"type": "uint256"
					},
					{
						"internalType": "bool",
						"name": "isAdopted",
						"type": "bool"
					},
					{
						"internalType": "uint256",
						"name": "purchaseTimestamp",
						"type": "uint256"
					}
				],
				"internalType": "struct CopyrightManagement.Copyright[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "getCopyright",
		"outputs": [
			{
				"internalType": "uint256",
				"name": "id",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "name",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "description",
				"type": "string"
			},
			{
				"internalType": "string",
				"name": "imageURL",
				"type": "string"
			},
			{
				"internalType": "uint256",
				"name": "price",
				"type": "uint256"
			},
			{
				"internalType": "bool",
				"name": "isAdopted",
				"type": "bool"
			},
			{
				"internalType": "uint256",
				"name": "purchaseTimestamp",
				"type": "uint256"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_copyrightId",
				"type": "uint256"
			}
		],
		"name": "verifyCopyright",
		"outputs": [
			{
				"internalType": "bool",
				"name": "",
				"type": "bool"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];
const CONTRACT_ADDRESS = '0x1471b97f58C286bB7C583a8A66F08d5846308Ff6';

window.addEventListener('load', async () => {
    const accountAddressElement = document.getElementById('accountAddress');
    const transactionListElement = document.getElementById('transactionList');
    const verifyCopyrightIdInput = document.getElementById('verifyCopyrightId');
    const verifyResultElement = document.getElementById('verifyResult');

    if (window.ethereum) {
        console.log("MetaMask is available!");

        // Use the provider from MetaMask
        window.web3 = new Web3(window.ethereum);

        try {
            // Request account access if needed
            await window.ethereum.request({ method: 'eth_requestAccounts' });

            // Get accounts
            const accounts = await web3.eth.getAccounts();
            console.log("Accounts fetched:", accounts);
            const currentAccount = accounts[0];
            accountAddressElement.innerText = currentAccount;

            // Load transactions
            console.log("Loading transactions...");
            await loadTransactions(currentAccount);

            // Attach the verifyCopyright function to the window object for global access
            window.verifyCopyright = async function () {
                const copyrightId = verifyCopyrightIdInput.value;
                if (copyrightId) {
                    const isVerified = await verifyCopyrightForAccount(currentAccount, copyrightId);
                    verifyResultElement.innerText = isVerified ? 'You own this copyright.' : 'You do not own this copyright.';
                } else {
                    verifyResultElement.innerText = 'Please enter a copyright ID.';
                }
            };
        } catch (error) {
            console.error("Error connecting to MetaMask", error);
            alert('Please allow access to MetaMask to use this app.');
        }
    } else {
        console.error("MetaMask not detected.");
        alert('Please install MetaMask to use this app.');
    }

    async function loadTransactions(account) {
        const contract = new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS);
        try {
            const allCopyrights = await contract.methods.getAllCopyrights().call();
            console.log("All copyrights fetched:", allCopyrights);

            transactionListElement.innerHTML = ''; // Clear the list before adding items

            allCopyrights.forEach((copyright, index) => {
                contract.methods.copyrightOwners(index).call().then(owner => {
                    if (owner.toLowerCase() === account.toLowerCase()) {
                        const transactionItem = document.createElement('div');
                        transactionItem.classList.add('transaction-item');
                        transactionItem.innerHTML = `
                            <span>Copyright ID: ${index} - ${copyright.name}</span>
                            <button class="btn btn-danger" onclick="refund(${index})">Refund</button>
                        `;
                        transactionListElement.appendChild(transactionItem);
                    }
                }).catch(err => console.error("Error fetching copyright owner:", err));
            });
        } catch (error) {
            console.error("Error loading transactions:", error);
        }
    }

    // Expose the refund function to the global scope by attaching it to the window object
    window.refund = async function(copyrightId) {
        const contract = new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS);
        try {
            // Fetch the purchase timestamp for the copyright
            const purchaseTimestamp = await contract.methods.copyrights(copyrightId).call().then(copyright => copyright.purchaseTimestamp);
            const currentTime = Math.floor(Date.now() / 1000); // Current time in seconds
    
            // Check if the refund request is within the 30-second window
            if (currentTime <= parseInt(purchaseTimestamp) + 30) {
                console.log("Requesting refund for ID:", copyrightId);
                await contract.methods.requestRefund(copyrightId).send({ from: accountAddressElement.innerText });
                alert('Refund successful.');
                loadTransactions(accountAddressElement.innerText); // Reload transactions after refund
            } else {
                alert('Refund is only available within 30 seconds of the transaction. You are not eligible for a refund.');
            }
        } catch (error) {
            console.error("Refund failed:", error);
            alert('Refund failed: ' + error.message);
        }
    };
    

    // Function to verify copyright ownership
    async function verifyCopyrightForAccount(account, copyrightId) {
        const contract = new web3.eth.Contract(CONTRACT_ABI, CONTRACT_ADDRESS);
        try {
            console.log("Verifying copyright for ID:", copyrightId);
            const result = await contract.methods.verifyCopyright(copyrightId).call({ from: account });
            return result;
        } catch (error) {
            console.error('Verification failed:', error);
            return false;
        }
    }
});
