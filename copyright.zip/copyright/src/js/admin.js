window.addEventListener('load', async () => {
    const createForm = document.getElementById('createCopyrightForm');
    const editForm = document.getElementById('editCopyrightForm');
    const deleteForm = document.getElementById('deleteCopyrightForm');
    const statusMessage = document.getElementById('statusMessage');
    
    const contractAddress = "0x1471b97f58C286bB7C583a8A66F08d5846308Ff6"; // Replace with your actual contract address
    const contractABI = [
        {
            "inputs": [],
            "stateMutability": "nonpayable",
            "type": "constructor"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                },
                {
                    "indexed": false,
                    "internalType": "address",
                    "name": "owner",
                    "type": "address"
                }
            ],
            "name": "CopyrightCreated",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightDeleted",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightEdited",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "purchaser",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightPurchased",
            "type": "event"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "verifier",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "CopyrightVerified",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "string",
                    "name": "_name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "_price",
                    "type": "uint256"
                }
            ],
            "name": "createCopyright",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "deleteCopyright",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "_name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "_imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "_price",
                    "type": "uint256"
                }
            ],
            "name": "editCopyright",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "purchaseCopyright",
            "outputs": [],
            "stateMutability": "payable",
            "type": "function"
        },
        {
            "anonymous": false,
            "inputs": [
                {
                    "indexed": true,
                    "internalType": "address",
                    "name": "recipient",
                    "type": "address"
                },
                {
                    "indexed": false,
                    "internalType": "uint256",
                    "name": "copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "RefundIssued",
            "type": "event"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "requestRefund",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "stateMutability": "payable",
            "type": "receive"
        },
        {
            "inputs": [],
            "name": "admin",
            "outputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "copyrightOwners",
            "outputs": [
                {
                    "internalType": "address",
                    "name": "",
                    "type": "address"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "",
                    "type": "uint256"
                }
            ],
            "name": "copyrights",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "id",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "price",
                    "type": "uint256"
                },
                {
                    "internalType": "bool",
                    "name": "isAdopted",
                    "type": "bool"
                },
                {
                    "internalType": "uint256",
                    "name": "purchaseTimestamp",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "getAllCopyrights",
            "outputs": [
                {
                    "components": [
                        {
                            "internalType": "uint256",
                            "name": "id",
                            "type": "uint256"
                        },
                        {
                            "internalType": "string",
                            "name": "name",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "description",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "imageURL",
                            "type": "string"
                        },
                        {
                            "internalType": "uint256",
                            "name": "price",
                            "type": "uint256"
                        },
                        {
                            "internalType": "bool",
                            "name": "isAdopted",
                            "type": "bool"
                        },
                        {
                            "internalType": "uint256",
                            "name": "purchaseTimestamp",
                            "type": "uint256"
                        }
                    ],
                    "internalType": "struct CopyrightManagement.Copyright[]",
                    "name": "",
                    "type": "tuple[]"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "getCopyright",
            "outputs": [
                {
                    "internalType": "uint256",
                    "name": "id",
                    "type": "uint256"
                },
                {
                    "internalType": "string",
                    "name": "name",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "description",
                    "type": "string"
                },
                {
                    "internalType": "string",
                    "name": "imageURL",
                    "type": "string"
                },
                {
                    "internalType": "uint256",
                    "name": "price",
                    "type": "uint256"
                },
                {
                    "internalType": "bool",
                    "name": "isAdopted",
                    "type": "bool"
                },
                {
                    "internalType": "uint256",
                    "name": "purchaseTimestamp",
                    "type": "uint256"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [
                {
                    "internalType": "uint256",
                    "name": "_copyrightId",
                    "type": "uint256"
                }
            ],
            "name": "verifyCopyright",
            "outputs": [
                {
                    "internalType": "bool",
                    "name": "",
                    "type": "bool"
                }
            ],
            "stateMutability": "view",
            "type": "function"
        }
    ]; // Replace with your contract ABI JSON

    let web3;
    let contract;
    let account;

    async function initWeb3() {
        if (window.ethereum) {
            web3 = new Web3(window.ethereum);
            contract = new web3.eth.Contract(contractABI, contractAddress);
            await ethereum.request({ method: 'eth_requestAccounts' });
            [account] = await web3.eth.getAccounts();
        } else {
            alert('Please install MetaMask to use this app.');
        }
    }

    createForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const name = document.getElementById('createName').value;
        const description = document.getElementById('createDescription').value;
        const imageURL = document.getElementById('createImageURL').value;
        const price = document.getElementById('createPrice').value;

        try {
            await contract.methods.createCopyright(name, description, imageURL, web3.utils.toWei(price, 'ether')).send({ from: account });
            statusMessage.innerText = 'Copyright created successfully!';
        } catch (error) {
            console.error('Error creating copyright:', error);
            statusMessage.innerText = 'Error creating copyright.';
        }
    });

    editForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const id = document.getElementById('editId').value;
        const name = document.getElementById('editName').value;
        const description = document.getElementById('editDescription').value;
        const imageURL = document.getElementById('editImageURL').value;
        const price = document.getElementById('editPrice').value;

        try {
            const copyright = await contract.methods.getCopyright(id).call();
            if (copyright.isAdopted) {
                statusMessage.innerText = 'Cannot edit purchased copyright.';
                return;
            }

            await contract.methods.editCopyright(id, name, description, imageURL, web3.utils.toWei(price, 'ether')).send({ from: account });
            statusMessage.innerText = 'Copyright edited successfully!';
        } catch (error) {
            console.error('Error editing copyright:', error);
            statusMessage.innerText = 'Error editing copyright.';
        }
    });

    deleteForm.addEventListener('submit', async (event) => {
        event.preventDefault();
        const id = document.getElementById('deleteId').value;

        try {
            const copyright = await contract.methods.getCopyright(id).call();
            if (copyright.isAdopted) {
                statusMessage.innerText = 'Cannot delete purchased copyright.';
                return;
            }

            await contract.methods.deleteCopyright(id).send({ from: account });
            statusMessage.innerText = 'Copyright deleted successfully!';
        } catch (error) {
            console.error('Error deleting copyright:', error);
            statusMessage.innerText = 'Error deleting copyright.';
        }
    });

    await initWeb3();
});
