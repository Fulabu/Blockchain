const CopyrightManagement = artifacts.require("CopyrightManagement");

contract("CopyrightManagement", (accounts) => {
    const [platformOwner, artist, buyer] = accounts; // Assign accounts
    let contractInstance;

    before(async () => {
        contractInstance = await CopyrightManagement.deployed();
    });

    it("should set the correct platform owner", async () => {
        const owner = await contractInstance.platformOwner();
        assert.equal(owner, platformOwner, "Platform owner is not set correctly");
    });

    it("should add a new copyright", async () => {
        const copyrightName = "Song A";
        const price = web3.utils.toWei("1", "ether");
        const saleType = 0; // 0 = CopyrightOnly

        await contractInstance.addCopyright(copyrightName, artist, price, saleType, { from: platformOwner });

        const copyright = await contractInstance.copyrights(1);
        assert.equal(copyright.name, copyrightName, "Copyright name mismatch");
        assert.equal(copyright.artist, artist, "Artist address mismatch");
        assert.equal(copyright.price.toString(), price, "Price mismatch");
        assert.equal(copyright.forSale, true, "For sale status should be true");
        assert.equal(copyright.saleType.toString(), saleType.toString(), "Sale type mismatch");
    });

    it("should allow a user to purchase a copyright", async () => {
        const copyrightId = 1; // Purchasing the copyright added above
        const saleType = 0; // CopyrightOnly
        const price = web3.utils.toWei("1", "ether");

        // Buyer purchases the copyright
        await contractInstance.purchaseCopyright(copyrightId, { from: buyer, value: price });

        const purchaseHistory = await contractInstance.getUserPurchaseHistory(buyer);
        
        console.log("Purchase History:", purchaseHistory); // Add this line for debugging
        
        assert.equal(purchaseHistory.length, 1, "Purchase history should have 1 entry");
        assert.equal(purchaseHistory[0].buyer, buyer, "Buyer address mismatch in purchase history");
        assert.equal(purchaseHistory[0].copyrightId.toString(), copyrightId.toString(), "Copyright ID mismatch in purchase history");
        assert.equal(purchaseHistory[0].price.toString(), price, "Purchase price mismatch in history");
        assert.equal(purchaseHistory[0].copyrightName, "Song A", "Copyright name mismatch in purchase history");
        assert.equal(purchaseHistory[0].saleType.toString(), saleType.toString(), "Sale type mismatch in purchase history");
    });

    it("should not allow a purchase with incorrect amount", async () => {
        const copyrightId = 1;
        const incorrectPrice = web3.utils.toWei("0.5", "ether");

        try {
            await contractInstance.purchaseCopyright(copyrightId, { from: buyer, value: incorrectPrice });
            assert.fail("Purchase should fail due to incorrect payment amount");
        } catch (error) {
            assert.include(error.message, "revert", "Expected revert due to incorrect payment amount");
        }
    });

    it("should not allow a non-owner to add a copyright", async () => {
        const copyrightName = "Song B";
        const price = web3.utils.toWei("1", "ether");
        const saleType = 0; // 0 = CopyrightOnly

        try {
            await contractInstance.addCopyright(copyrightName, artist, price, saleType, { from: buyer });
            assert.fail("Only owner should be able to add copyrights");
        } catch (error) {
            assert.include(error.message, "revert", "Expected revert due to onlyOwner modifier");
        }
    });
});
